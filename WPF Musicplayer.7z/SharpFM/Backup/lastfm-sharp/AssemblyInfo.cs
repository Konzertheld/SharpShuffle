// AssemblyInfo.cs created with MonoDevelop
// User: amr at 3:29 PM 10/24/2008

using System.Reflection;
using System.Runtime.CompilerServices;

// Information about this assembly is defined by the following attributes. 
// Change them to the values specific to your project.

[assembly: AssemblyTitle("lastfm-sharp")]
[assembly: AssemblyDescription("A CIL interface to Last.fm.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("lastfm-sharp")]
[assembly: AssemblyCopyright("Amr Hassan")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// The assembly version has the format "{Major}.{Minor}.{Build}.{Revision}".
// If the build and revision are set to '*' they will be updated automatically.

[assembly: AssemblyVersion("0.2.1.*")]

// The following attributes are used to specify the signing key for the assembly, 
// if desired. See the Mono documentation for more information about signing.

[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]
